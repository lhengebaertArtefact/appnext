
export default function Products() {
    return (
      <div>
        <h1>Products List</h1>
        <h3>Product 1</h3>
        <h3>Product 2</h3>
        <h3>Product 3</h3>
      </div>
    )
   
  }